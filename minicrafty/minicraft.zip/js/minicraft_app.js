/*

	minicraft_app.js
	
	Beherbergt das Datenmodel innerhalb von JS mittels AngularJS


*/

// Hauptanwendung 
var app = angular.module('mcMapApp', []);



